# Import packages
import os, sys
os.environ["CUDA_VISIBLE_DEVICES"] = "0" #put '-1' instead of '0' if u don't want to use GPU
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from tensorflow.keras.optimizers import Adam, SGD, RMSprop, Adadelta, Adagrad, Adamax, Nadam, Ftrl
from keras.callbacks import EarlyStopping, ModelCheckpoint
from math import floor
from bayes_opt import BayesianOptimization
from sklearn.datasets import make_circles
from sklearn.metrics import accuracy_score, recall_score, precision_score, confusion_matrix, classification_report, roc_auc_score, cohen_kappa_score, f1_score, make_scorer
from keras.models import Sequential, load_model, Model
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from keras import regularizers, layers
from keras.layers.embeddings import Embedding
from keras.preprocessing import sequence
from sklearn.model_selection import RepeatedKFold
from pickle import load
from numpy import array, argmax
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils.vis_utils import plot_model
from keras.layers import Input, Dense, Flatten, Dropout, Embedding, BatchNormalization, concatenate, LSTM, LeakyReLU
from keras.layers.convolutional import Conv2D, MaxPooling2D
import os, sys, itertools, numpy as np, tensorflow as tf, tensorflow, numpy, matplotlib.pyplot as plt, seaborn as sns, pandas as pd, warnings
from keras.constraints import MaxNorm as maxnorm
from tensorflow.keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import RandomizedSearchCV
from multiprocessing import Pool
print("Library Loaded")
LeakyReLU = LeakyReLU(alpha=0.1)
warnings.filterwarnings('ignore')
score_acc = make_scorer(accuracy_score)
def mono_hot_encode(seq):
	mapping = dict(zip(['A','T','G','C'], range(4)))  
	text=[seq[i:i+1] for i in range(len(seq)-(1-1))]
	seq1 = [mapping[i] for i in text]
	return np.eye(4)[seq1]


def kmers(file1,k):
	seq_id1 = []
	kmer1 = []
	for line in file1:
		if line.startswith(">"):
			seq_id = line.strip()
		else:
			if(len(line) >= 400):
				for i in range(0,len(line)-k+1):
					kmer = line[i:i+k]
					seq = seq_id + "_" + str(i)
					seq_id1.append(seq)
					kmer1.append(kmer)
			elif(len(line) >= 200):
				seq_id1.append(seq_id)
				kmer1.append(line)
	return(seq_id1,kmer1)

def s1(k):
	texts_mono_fold = []
	texts_mono_fold.append(mono_hot_encode1(test12[k]))
	padded_docs3 = pad_sequences(texts_mono_fold, maxlen=400, padding='post') 
	texts_mono = []
	lab = testlab[k]
	texts_mono.append(mono_hot_encode(testseq[k]))
	padded_docs4 = pad_sequences(texts_mono, maxlen=400, padding='post')
	return lab, padded_docs4, padded_docs3



def mono_hot_encode1(seq):
	mapping = dict(zip(['.',')','('], range(3)))  
	text=[seq[i:i+1] for i in range(len(seq)-(1-1))]
	seq1 = [mapping[i] for i in text]
	return np.eye(3)[seq1]


print("Function Loaded")
filename=str(sys.argv[1])  #name of your input file
testseq=[]
testlab=[];test12=[]
for i in open(filename):
	z=i.split()
	testlab.append(int(z[0]))
	testseq.append(str(z[1]))
	test12.append(z[2])


name=[]
name = Pool().map(s1, [sent for sent in range(len(testseq))])
input_ids=[]
attention_masks=[]
attention_masks_fold=[]
for i, j in enumerate(name):
	input_ids.append(name[i][0])	
	attention_masks.append(name[i][1])
	attention_masks_fold.append(name[i][2])

X = numpy.array(attention_masks).reshape(len(numpy.array(attention_masks)),400,4,1);attention_masks=[]
y = numpy.array(input_ids);input_ids=[]
Z = numpy.array(attention_masks_fold).reshape(len(numpy.array(attention_masks_fold)),400,3,1);attention_masks_fold=[]
train_inp, test_inp, train_label, test_label,train_fold, test_fold = train_test_split(X, y, Z,test_size=0.2) #split your input file accordingly
print("Data and Parameter Loaded")
#Create the objective function containing the Neural Network model for structure based input. The function will return returns the score of the validation data#
def nn_cl_bo(neurons, activation, optimizer, learning_rate, batch_size, kernelOne, kernelTwo, epochs, dropout_rate):
	optimizerL = ['SGD', 'Adam', 'RMSprop', 'Adadelta', 'Adagrad', 'Adamax', 'Nadam', 'Ftrl','SGD']
	optimizerD= {'Adam':Adam(lr=learning_rate), 'SGD':SGD(lr=learning_rate),
                 'RMSprop':RMSprop(lr=learning_rate), 'Adadelta':Adadelta(lr=learning_rate),
                 'Adagrad':Adagrad(lr=learning_rate), 'Adamax':Adamax(lr=learning_rate),
                 'Nadam':Nadam(lr=learning_rate), 'Ftrl':Ftrl(lr=learning_rate)}
	activationL = ['relu', 'sigmoid', 'softplus', 'softsign', 'tanh', 'selu',
                   'elu', activation, LeakyReLU,'relu']
	neurons = round(neurons)
	activation = activationL[round(activation)]
	optimizer = optimizerD[optimizerL[round(optimizer)]]
	batch_size = round(batch_size)
	epochs = round(epochs)
	kernelOne = round(kernelOne)
	kernelTwo = round(kernelTwo)
	def nn_cl_fun():
		inputShape2 = (400, 3, 1)
		inputs2 = Input(shape=inputShape2)
		conv2 = Conv2D(kernelOne, (3, 3), padding='same', activation=activation, kernel_constraint=maxnorm(3))(inputs2)
		batch3 = BatchNormalization()(conv2)
		pool2 = MaxPooling2D(pool_size=(2, 2), padding='same')(batch3)
		conv3 = Conv2D(kernelTwo, (3, 3), padding='same', activation=activation, kernel_constraint=maxnorm(3))(pool2)
		batch4 = BatchNormalization()(conv3)
		pool3 = MaxPooling2D(pool_size=(2, 2))(batch4)
		flat2 = Flatten()(pool3)
		dense4 = Dense(neurons, activation=activation)(flat2)
		batch5 = BatchNormalization()(dense4)
		dense2 = Dense(neurons, activation=activation)(batch5)
		batch_model = BatchNormalization(name="my_dense")(dense2)
		drop = Dropout(dropout_rate)(batch_model)
		outputs = Dense(1, activation=activation)(drop)
		nn = Model(inputs=inputs2, outputs=outputs)
		nn.compile(loss='mean_absolute_error', optimizer=optimizer, metrics=['accuracy'])
		return nn
	es = EarlyStopping(monitor='accuracy', mode='max', verbose=0, patience=20)
	nn = KerasClassifier(build_fn=nn_cl_fun, epochs=epochs, batch_size=batch_size, verbose=0)
	kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=123)
	score = cross_val_score(nn,  train_fold, train_label, scoring=score_acc, cv=kfold, fit_params={'callbacks':[es]}).mean()
	return score

#Set the range of hyperparameters and run the Bayesian Optimization#
params_nn ={
    'neurons': (8, 64),
    'activation':(0, 9),
    'optimizer':(0,7),
    'learning_rate':(0.01, 1),
    'batch_size':(20, 140),
    'epochs':(20, 100),
    'kernelOne':(8,64),
    'kernelTwo':(8,64),
    'dropout_rate':(0,1)
}	
nn_bo = BayesianOptimization(nn_cl_bo, params_nn)
nn_bo.maximize(init_points=10, n_iter=4)	
params_nn_ = nn_bo.max['params']
learning_rate = params_nn_['learning_rate']
activationL = ['relu', 'sigmoid', 'softplus', 'softsign', 'tanh', 'selu',
               'elu', 'exponential', LeakyReLU,'relu']
params_nn_['activation'] = activationL[round(params_nn_['activation'])]
params_nn_['batch_size'] = round(params_nn_['batch_size'])
params_nn_['epochs'] = round(params_nn_['epochs'])
params_nn_['kernelOne'] = round(params_nn_['kernelOne'])
params_nn_['kernelTwo'] = round(params_nn_['kernelTwo'])
params_nn_['neurons'] = round(params_nn_['neurons'])
optimizerL = ['Adam', 'SGD', 'RMSprop', 'Adadelta', 'Adagrad', 'Adamax', 'Nadam', 'Ftrl','Adam']
optimizerD= {'Adam':Adam(lr=learning_rate), 'SGD':SGD(lr=learning_rate),
             'RMSprop':RMSprop(lr=learning_rate), 'Adadelta':Adadelta(lr=learning_rate),
             'Adagrad':Adagrad(lr=learning_rate), 'Adamax':Adamax(lr=learning_rate),
             'Nadam':Nadam(lr=learning_rate), 'Ftrl':Ftrl(lr=learning_rate)}
params_nn_['optimizer'] = optimizerD[optimizerL[round(params_nn_['optimizer'])]]
#Create the objective function containing the Neural Network model for sequence based input. The function will return returns the score of the validation data#
def nn_cl_boo(neurons, activation, optimizer, learning_rate, batch_size, kernelOne,epochs, dropout_rate):
	optimizerL = ['SGD', 'Adam', 'RMSprop', 'Adadelta', 'Adagrad', 'Adamax', 'Nadam', 'Ftrl','SGD']
	optimizerD= {'Adam':Adam(lr=learning_rate), 'SGD':SGD(lr=learning_rate),
                 'RMSprop':RMSprop(lr=learning_rate), 'Adadelta':Adadelta(lr=learning_rate),
                 'Adagrad':Adagrad(lr=learning_rate), 'Adamax':Adamax(lr=learning_rate),
                 'Nadam':Nadam(lr=learning_rate), 'Ftrl':Ftrl(lr=learning_rate)}
	activationL = ['relu', 'sigmoid', 'softplus', 'softsign', 'tanh', 'selu',
                   'elu', activation, LeakyReLU,'relu']
	neurons = round(neurons)
	activation = activationL[round(activation)]
	optimizer = optimizerD[optimizerL[round(optimizer)]]
	batch_size = round(batch_size)
	epochs = round(epochs)
	kernelOne = round(kernelOne)
	def nn_cl_fun():
		inputShape1 = (400, 4, 1)
		inputs1 = Input(shape=inputShape1)
		conv1 = Conv2D(kernelOne, (3, 3), padding='same', activation=activation, kernel_constraint=maxnorm(3))(inputs1)
		batch1 = BatchNormalization()(conv1)
		pool1 = MaxPooling2D(pool_size=(2, 2))(batch1)
		flat1 = Flatten()(pool1)
		dense3 = Dense(neurons, activation=activation)(flat1)
		batch2 = BatchNormalization()(dense3)
		dense1 = Dense(neurons, activation=activation)(batch2)
		batch_model = BatchNormalization(name="my_dense")(dense1)
		drop = Dropout(dropout_rate)(batch_model)
		outputs = Dense(1, activation=activation)(drop)
		nn = Model(inputs=inputs1, outputs=outputs)
		nn.compile(loss='mean_absolute_error', optimizer=optimizer, metrics=['accuracy'])
		return nn
	es = EarlyStopping(monitor='accuracy', mode='max', verbose=0, patience=20)
	nn = KerasClassifier(build_fn=nn_cl_fun, epochs=epochs, batch_size=batch_size, verbose=0)
	kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=123)
	score = cross_val_score(nn,train_inp, train_label, scoring=score_acc, cv=kfold, fit_params={'callbacks':[es]}).mean()
	return score

#Set the range of hyperparameters and run the Bayesian Optimization#
params_nnn ={
    'neurons': (8, 64),
    'activation':(0, 9),
    'optimizer':(0,7),
    'learning_rate':(0.01, 1),
    'batch_size':(20, 140),
    'kernelOne':(8,64),
    'epochs':(8,64),
    'dropout_rate':(0,1)
}	
nn_boo = BayesianOptimization(nn_cl_boo, params_nnn)
nn_boo.maximize(init_points=10, n_iter=4)	
params_nnn_ = nn_boo.max['params']
learning_rate = params_nnn_['learning_rate']
activationL = ['relu', 'sigmoid', 'softplus', 'softsign', 'tanh', 'selu',
               'elu', 'exponential', LeakyReLU,'relu']
params_nnn_['activation'] = activationL[round(params_nnn_['activation'])]
params_nnn_['batch_size'] = round(params_nnn_['batch_size'])
params_nnn_['epochs'] = round(params_nnn_['epochs'])
params_nnn_['layers1'] = round(params_nnn_['layers1'])
params_nnn_['layers2'] = round(params_nnn_['layers2'])
params_nnn_['neurons'] = round(params_nnn_['neurons'])
optimizerL = ['Adam', 'SGD', 'RMSprop', 'Adadelta', 'Adagrad', 'Adamax', 'Nadam', 'Ftrl','Adam']
optimizerD= {'Adam':Adam(lr=learning_rate), 'SGD':SGD(lr=learning_rate),
             'RMSprop':RMSprop(lr=learning_rate), 'Adadelta':Adadelta(lr=learning_rate),
             'Adagrad':Adagrad(lr=learning_rate), 'Adamax':Adamax(lr=learning_rate),
             'Nadam':Nadam(lr=learning_rate), 'Ftrl':Ftrl(lr=learning_rate)}
params_nnn_['optimizer'] = optimizerD[optimizerL[round(params_nnn_['optimizer'])]]
# Fit the model on obtained hyperparameters with changing optimizer#
opti=[]
optimizerL = ['Adam', 'RMSprop', 'Adadelta', 'Adagrad', 'Adamax', 'Nadam', 'Ftrl','SGD']
for opti in optimizerL:
	inputShape1 = (400, 4, 1)
	inputs1 = Input(shape=inputShape1)
	conv1 = Conv2D(params_nnn_['kernelOne'], (3, 3), padding='same', activation=params_nnn_['activation'], kernel_constraint=maxnorm(3))(inputs1)
	batch1 = BatchNormalization()(conv1)
	pool1 = MaxPooling2D(pool_size=(2, 2))(batch1)
	flat1 = Flatten()(pool1)
	dense3 = Dense(params_nnn_['neurons'], activation=params_nnn_['activation'])(flat1)
	batch2 = BatchNormalization()(dense3)
	dense1 = Dense(params_nnn_['neurons'], activation=params_nnn_['activation'])(batch2)																			
	inputShape2 = (400, 3, 1)
	inputs2 = Input(shape=inputShape2)
	conv2 = Conv2D(params_nn_['kernelOne'], (3, 3), padding='same', activation=params_nn_['activation'], kernel_constraint=maxnorm(3))(inputs2)
	batch3 = BatchNormalization()(conv2)
	pool2 = MaxPooling2D(pool_size=(2, 2), padding='same')(batch3)
	conv3 = Conv2D(params_nn_['kernelOne'], (3, 3), padding='same', activation=params_nn_['activation'], kernel_constraint=maxnorm(3))(pool2)
	batch4 = BatchNormalization()(conv3)
	pool3 = MaxPooling2D(pool_size=(2, 2))(batch4)
	flat2 = Flatten()(pool3)
	dense4 = Dense(params_nn_['neurons'], activation=params_nnn_['activation'])(flat2)
	batch5 = BatchNormalization()(dense4)
	dense2 = Dense(params_nn_['neurons'], activation=params_nnn_['activation'])(batch5)
	mode = concatenate([dense1,dense2])
	batch_model = BatchNormalization(name="my_dense")(mode)
	drop = Dropout(params_nn_['dropout'])(batch_model)
	outputs = Dense(1, activation="sigmoid")(drop)
	nn = Model(inputs=[inputs1,inputs2], outputs=outputs)
	checkpoint_filepath = 'checkpoint'+str(opti)
	nn.compile(loss='mean_absolute_error', optimizer=opti, metrics=['accuracy'])      
	model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(filepath= checkpoint_filepath, save_weights_only=True, monitor='val_accuracy', mode='max', save_best_only=True)
	nn = KerasClassifier(build_fn=nn_cl_fun, epochs=params_nn_['epochs'], batch_size=params_nn_['batch_size'], verbose=0)
	history=nn.fit([train_inp, train_fold], train_label,epochs=50, batch_size=params_nn_['batch_size'], validation_data=([test_inp, test_fold], test_label),callbacks=[model_checkpoint_callback])
	opti.append(int(history.history['accuracy']))



max_value = max(opti)
max_index = opti.index(max_value)
optimizer = optimizerL[max_index]
# Fit the model on obtained hyperparameters with changing activation function#
acti=[]
model_nn=[]
activationL = ['exponential','relu', 'sigmoid', 'softplus', 'softsign', 'tanh', 'elu','LeakyReLU','selu']
for act in activationL:
	inputShape1 = (400, 4, 1)
	inputs1 = Input(shape=inputShape1)
	conv1 = Conv2D(params_nnn_['kernelOne'], (3, 3), padding='same', activation=params_nnn_['activation'], kernel_constraint=maxnorm(3))(inputs1)
	batch1 = BatchNormalization()(conv1)
	pool1 = MaxPooling2D(pool_size=(2, 2))(batch1)
	flat1 = Flatten()(pool1)
	dense3 = Dense(params_nnn_['neurons'], activation=params_nnn_['activation'])(flat1)
	batch2 = BatchNormalization()(dense3)
	dense1 = Dense(params_nnn_['neurons'], activation=params_nnn_['activation'])(batch2)																			
	inputShape2 = (400, 3, 1)
	inputs2 = Input(shape=inputShape2)
	conv2 = Conv2D(params_nn_['kernelOne'], (3, 3), padding='same', activation=params_nn_['activation'], kernel_constraint=maxnorm(3))(inputs2)
	batch3 = BatchNormalization()(conv2)
	pool2 = MaxPooling2D(pool_size=(2, 2), padding='same')(batch3)
	conv3 = Conv2D(params_nn_['kernelOne'], (3, 3), padding='same', activation=params_nn_['activation'], kernel_constraint=maxnorm(3))(pool2)
	batch4 = BatchNormalization()(conv3)
	pool3 = MaxPooling2D(pool_size=(2, 2))(batch4)
	flat2 = Flatten()(pool3)
	dense4 = Dense(params_nn_['neurons'], activation=params_nnn_['activation'])(flat2)
	batch5 = BatchNormalization()(dense4)
	dense2 = Dense(params_nn_['neurons'], activation=params_nnn_['activation'])(batch5)
	mode = concatenate([dense1,dense2])
	batch_model = BatchNormalization(name="my_dense")(mode)
	drop = Dropout(params_nn_['dropout'])(batch_model)
	outputs = Dense(1, activation=act)(drop)
	nn = Model(inputs=[inputs1,inputs2], outputs=outputs)
	checkpoint_filepath = 'checkpoint'+str(act)
	nn.compile(loss='mean_absolute_error', optimizer=optimizer, metrics=['accuracy'])      
	model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(filepath= checkpoint_filepath, save_weights_only=True, monitor='val_accuracy', mode='max', save_best_only=True)
	nn = KerasClassifier(build_fn=nn_cl_fun, epochs=params_nn_['epochs'], batch_size=params_nn_['batch_size'], verbose=0)
	history=nn.fit([train_inp, train_fold], train_label,epochs=50, batch_size=params_nn_['batch_size'], validation_data=([test_inp, test_fold], test_label),callbacks=[model_checkpoint_callback])
	acti.append(int(history.history['accuracy']))
	model_nn.append(nn)

max_value = max(acti)
max_index = acti.index(max_value)
print(activationL[max_index])
print(model_nn[max_index].summary())
