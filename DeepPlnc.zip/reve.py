#!user/bin/python
import sys, os
import numpy as np
import random
from Bio.Seq import Seq


infile=[x.strip() for x in open(sys.argv[1]).readlines()]
fastadict={}
for line in infile:
    if not line:
        continue
    if line.startswith('>'):
        sname = line
        if line not in fastadict:
            fastadict[line] = ''
        continue
    fastadict[sname] += line

ids=list(fastadict.keys())
seq = list(fastadict.values())

f3=open(sys.argv[1]+".fasta",'w')
f4=open(sys.argv[1]+"-rev",'w')
for i,j in enumerate(seq):
	j=j.replace('U', 'T')
	j=j.replace('N', 'A')
	f3.writelines(str(ids[i])+"\n"+str(j.upper())+"\n")
	seqs = Seq(j)
	f3.writelines(str(ids[i])+"-rev\n"+str(seqs.reverse_complement().upper())+"\n")
	print(str(ids[i]).replace('>', ''))
	f4.writelines(str(str(ids[i]).replace('>', '')+"-rev")+"\n")
	
	
	
f3.close()
f4.close()
